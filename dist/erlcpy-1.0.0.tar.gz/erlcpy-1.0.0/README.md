# ER:LC API Wrapper
A Python API wrapper for the ER:LC API.

## Installation
First you need to install the package.

`pip install erlcpy`

### Setup
Setup is easy:

```python
WORKING PROGRESS
```
Now you can start using the API - here are a few examples:

```python
WORKING PROGRESS
```

### [PRC API Documentation](https://apidocs.policeroleplay.community/reference/api-reference)

### Credits
Collaborator - [Missile05](https://discord.com/users/591298352344334388)

Documentation Inspiration - [0xRaptor](https://twitter.com/0xRaptorRblx)
