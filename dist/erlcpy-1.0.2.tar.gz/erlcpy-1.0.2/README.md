# ER:LC API Wrapper
A Python API wrapper for the ER:LC API.

## Installation
First you need to install the package.

`pip install erlcpy`

### Setup
Setup is easy:

```python
CODE EXAMPLES IN WORKING PROGRESS
```
Now you can start using the API - here are a few examples:

```python
CODE EXAMPLES IN WORKING PROGRESS
```

### [PRC API Documentation](https://apidocs.policeroleplay.community/reference/api-reference)
### [Our PyPi Package](https://pypi.org/project/erlcpy/1.0.0/)

### Credits
Collaborator - [Missile05](https://discord.com/users/591298352344334388)

Documentation Inspiration - [0xRaptor](https://twitter.com/0xRaptorRblx)
